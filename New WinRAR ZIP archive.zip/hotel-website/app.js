const express = require('express');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded({ extended: true }));

// Parse JSON bodies (as sent by API clients)
app.use(express.json());

// Routes
app.get('/', (req, res) => {
  res.render('layout', { 
    title: 'Luxury Hotel & Resort',
    active: 'home',
    view: 'index'
  });
});

app.get('/rooms', (req, res) => {
  res.render('layout', { 
    title: 'Our Rooms & Suites',
    active: 'rooms',
    view: 'rooms'
  });
});

app.get('/dining', (req, res) => {
  res.render('layout', { 
    title: 'Dining & Restaurants',
    active: 'dining',
    view: 'dining'
  });
});

app.get('/facilities', (req, res) => {
  res.render('layout', { 
    title: 'Hotel Facilities',
    active: 'facilities',
    view: 'facilities'
  });
});

app.get('/contact', (req, res) => {
  res.render('layout', { 
    title: 'Contact Us',
    active: 'contact',
    view: 'contact'
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Hotel website app listening at http://localhost:${port}`);
}); 