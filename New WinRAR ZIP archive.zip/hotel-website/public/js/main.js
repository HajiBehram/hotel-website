document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Enhanced Navbar on scroll
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    }

    // Add animation classes on scroll - Enhanced with random animations
    const animateOnScroll = function() {
        const elements = document.querySelectorAll('.animate-on-scroll');
        const imageAnimations = ['zoom-in', 'flip-in', 'blur-in', 'fade-in'];
        const textAnimations = ['fade-in', 'slide-in-left', 'slide-in-right', 'slide-up', 'scale-in'];
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            
            // Check if element is in viewport
            if (elementPosition.top < windowHeight - 50) {
                let animation;
                // If data-animation is specified, use that
                if (element.getAttribute('data-animation')) {
                    animation = element.getAttribute('data-animation');
                } else {
                    // Else assign random animation based on element type
                    if (element.tagName === 'IMG' || element.classList.contains('gallery-img') || 
                        element.classList.contains('img-overlay-container')) {
                        animation = imageAnimations[Math.floor(Math.random() * imageAnimations.length)];
                    } else {
                        animation = textAnimations[Math.floor(Math.random() * textAnimations.length)];
                    }
                }
                
                element.classList.add(animation);
                element.classList.remove('animate-on-scroll');
            }
        });
    };

    // Add hover effects to all images
    const addHoverEffectsToImages = function() {
        const images = document.querySelectorAll('.gallery-img, .room-card img, .facility-card img');
        const hoverEffects = ['hover-zoom', 'hover-shadow', 'hover-saturate'];
        
        images.forEach(img => {
            if (!img.classList.contains('hover-lift') && !img.classList.contains('hover-glow')) {
                const randomEffect = hoverEffects[Math.floor(Math.random() * hoverEffects.length)];
                img.classList.add(randomEffect);
            }
        });
    };
    
    addHoverEffectsToImages();

    // Fix for background image scroll issues
    const fixHeroBackgroundScroll = function() {
        const heroSections = document.querySelectorAll('.hero-section');
        heroSections.forEach(section => {
            const style = window.getComputedStyle(section);
            const bgImage = style.backgroundImage;
            
            // Set to fixed attachment to prevent parallax issues
            if (bgImage && bgImage !== 'none') {
                section.style.backgroundAttachment = 'fixed';
            }
        });
    };
    
    fixHeroBackgroundScroll();

    // Run once on page load
    animateOnScroll();
    
    // Run on scroll
    window.addEventListener('scroll', animateOnScroll);

    // Hero section parallax effect - modified to work better
    const heroSection = document.querySelector('.hero-section');
    if (heroSection) {
        // Instead of changing backgroundPositionY, we'll use a different approach
        // Add a subtle transform to hero content for parallax feel
        const heroContent = heroSection.querySelector('.hero-content');
        if (heroContent) {
            window.addEventListener('scroll', function() {
                const scrollPosition = window.pageYOffset;
                const translateY = scrollPosition * 0.1;
                if (scrollPosition < heroSection.offsetHeight) {
                    heroContent.style.transform = `translateY(${translateY}px)`;
                }
            });
        }
    }

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 70,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Back to top button
    const backToTopBtn = document.getElementById('back-to-top');
    if (backToTopBtn) {
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        });

        backToTopBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Random animation for service icons
    const serviceIcons = document.querySelectorAll('.service-icon i');
    const animations = ['bounce', 'rotate-in', 'scale-in', 'swing'];
    
    serviceIcons.forEach(icon => {
        icon.addEventListener('mouseover', function() {
            const randomAnimation = animations[Math.floor(Math.random() * animations.length)];
            this.classList.add(randomAnimation);
            
            this.addEventListener('animationend', function() {
                this.classList.remove(randomAnimation);
            }, { once: true });
        });
    });

    // Text highlight effect for headings
    const headings = document.querySelectorAll('h1:not(.hero-title), h2:not(.section-title), h3, h4, h5');
    headings.forEach(heading => {
        heading.addEventListener('mouseover', function() {
            this.style.color = '#b8860b';
            this.style.transition = 'color 0.3s ease';
        });
        heading.addEventListener('mouseout', function() {
            this.style.color = '';
        });
    });

    // Enhanced image hover effects
    const enhanceImageEffects = function() {
        const imgContainers = document.querySelectorAll('.img-overlay-container');
        imgContainers.forEach(container => {
            container.addEventListener('mouseover', function() {
                const btn = this.querySelector('.img-overlay .btn');
                if (btn) {
                    btn.classList.add('pulse-animation');
                }
            });
            container.addEventListener('mouseout', function() {
                const btn = this.querySelector('.img-overlay .btn');
                if (btn) {
                    btn.classList.remove('pulse-animation');
                }
            });
        });
    };
    
    enhanceImageEffects();

    // Form validation
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            let isValid = true;
            const requiredFields = contactForm.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                } else {
                    field.classList.remove('is-invalid');
                }
            });

            const emailField = contactForm.querySelector('input[type="email"]');
            if (emailField && emailField.value.trim()) {
                const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailPattern.test(emailField.value)) {
                    isValid = false;
                    emailField.classList.add('is-invalid');
                }
            }
            
            if (!isValid) {
                e.preventDefault();
                const firstInvalid = contactForm.querySelector('.is-invalid');
                if (firstInvalid) {
                    firstInvalid.focus();
                }
            } else {
                // Normally would send to server, but for demo we'll just show a success message
                e.preventDefault();
                document.getElementById('contactFormSuccess').classList.remove('d-none');
                contactForm.reset();
                setTimeout(() => {
                    document.getElementById('contactFormSuccess').classList.add('d-none');
                }, 5000);
            }
        });

        // Animate form fields on focus
        const formFields = contactForm.querySelectorAll('input, textarea');
        formFields.forEach(field => {
            field.addEventListener('focus', function() {
                this.classList.add('hover-glow');
            });
            field.addEventListener('blur', function() {
                this.classList.remove('hover-glow');
            });
        });
    }

    // Room booking date range
    const checkInDate = document.getElementById('check-in-date');
    const checkOutDate = document.getElementById('check-out-date');
    
    if (checkInDate && checkOutDate) {
        // Set min date to today
        const today = new Date();
        const dd = String(today.getDate()).padStart(2, '0');
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const yyyy = today.getFullYear();
        
        const todayStr = yyyy + '-' + mm + '-' + dd;
        checkInDate.min = todayStr;
        
        // Update check-out min date when check-in date changes
        checkInDate.addEventListener('change', function() {
            if (checkInDate.value) {
                checkOutDate.min = checkInDate.value;
                
                // If check-out date is before check-in date, reset it
                if (checkOutDate.value && checkOutDate.value < checkInDate.value) {
                    checkOutDate.value = '';
                }
            }
        });
    }

    // Enhance all gallery images with hover effects
    const galleryImages = document.querySelectorAll('.gallery-img');
    galleryImages.forEach(img => {
        img.classList.add('hover-lift');
    });

    // Testimonial card animation effects
    const testimonialCards = document.querySelectorAll('.testimonial-card');
    testimonialCards.forEach((card, index) => {
        if (index % 2 === 0) {
            card.classList.add('hover-rotate');
        } else {
            card.classList.add('hover-lift');
        }
    });

    // Facility card hover effects
    const facilityCards = document.querySelectorAll('.facility-card');
    facilityCards.forEach(card => {
        card.classList.add('hover-glow');
    });
}); 