# Luxury Hotel & Resort Website

A modern, responsive hotel website built with Node.js, Express, and EJS. This project showcases a luxury hotel with various features including room booking, services, and contact functionality.

## Features

- Responsive design that works on all devices
- Modern and elegant UI with a focus on user experience
- Room booking functionality
- Image galleries
- Testimonials section
- Contact form with validation
- Interactive elements

## Tech Stack

- **Node.js** - JavaScript runtime
- **Express.js** - Web application framework
- **EJS** - Templating engine
- **Bootstrap 5** - CSS framework
- **Font Awesome** - Icon library
- **Custom CSS** - For unique styling elements

## Project Structure

```
hotel-website/
│
├── public/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   └── images/
│
├── views/
│   ├── layout.ejs
│   ├── index.ejs
│   ├── rooms.ejs
│   ├── dining.ejs
│   ├── facilities.ejs
│   └── contact.ejs
│
├── routes/
│
├── app.js
├── package.json
└── README.md
```

## Installation

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
3. Start the server:
   ```
   npm start
   ```
4. Open your browser and navigate to `http://localhost:3000`

## Usage

The website includes the following pages:

- **Home** - Main landing page with hotel highlights
- **Rooms & Suites** - Showcases available accommodations
- **Dining** - Displays restaurant and dining options
- **Facilities** - Shows hotel amenities and facilities
- **Contact** - Contains a contact form and hotel information

## Customization

You can customize the website by:

1. Modifying the EJS templates in the `views` directory
2. Updating styles in `public/css/style.css`
3. Adding your own images to `public/images/`
4. Extending functionality in `app.js`

## License

This project is licensed under the ISC License.

## Acknowledgments

- Images from [Unsplash](https://unsplash.com)
- Icons from [Font Awesome](https://fontawesome.com)
- CSS framework by [Bootstrap](https://getbootstrap.com) 